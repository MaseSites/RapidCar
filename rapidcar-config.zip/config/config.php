<?php

// RapidCar Serverkonfiguration fuer rapid-car.com.
// Enthaelt Schluessel: Datei niemals oeffentlich machen oder einchecken.
//
// Vollstaendig eingerichtet: OpenAI, Stripe (Schluessel + Webhook), Spyne.
// Offen ist nur noch background.scenes: die Szenen-Nummern aus dem
// Spyne-Konto eintragen, damit die Spyne-Hintergruende waehlbar werden.

return array (
  'app' =>
  array (
    'url' => 'https://rapid-car.com',
    'key' => 'hGrd9UN5TPZ1L6P5C9q1eGAQFxHsN/SjknkYfvtgoss=',
    'debug' => false,
    'name' => 'RapidCar',
    'timezone' => 'Europe/Zurich',
    'force_https' => false,
    'pretty_urls' => true,
  ),
  'db' =>
  array (
    'driver' => 'sqlite',
    'sqlite_path' => __DIR__ . '/../storage/database.sqlite',
  ),
  'mail' =>
  array (
    'driver' => 'mail',
    'host' => '',
    'port' => 587,
    'username' => '',
    'password' => '',
    'encryption' => 'tls',
    'from' => 'info@rapid-car.com',
    'from_name' => 'RapidCar',
    'contact' => 'info@rapid-car.com',
  ),
  'features' =>
  array (
    'email_verification' => true,
  ),
  'ai' =>
  array (
    'mode' => 'live',
    'api_key' => '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',
    'model' => 'gpt-4o-mini',
    'vision_model' => '',
    'api_url' => '',
    'image_detail' => 'low',
    'detection_detail' => 'high',
    'image_quality' => 'medium',
  ),
  'uploads' =>
  array (
    'max_file_size_mb' => 12,
    'max_images_per_vehicle' => 20,
  ),

  // Freistellen und Hintergruende ueber Spyne.
  // api_key: kommt von Spyne nach Vertragsabschluss.
  // api_key_header: nur setzen, wenn Spyne eine abweichende Kopfzeile nennt.
  // scenes: die Studio-Hintergruende aus deinem Spyne-Konto.
  //   Kennung (Zahl von Spyne) => Anzeigename in der Auswahl.
  //   Diese Szenen ersetzen die mitgelieferten Hintergruende.
  // Solange api_key leer ist, bleibt alles ehrlich beim bisherigen Stand.
  'background' =>
  array (
    'provider' => 'spyne',
    'api_key' => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbnRlcnByaXNlSWQiOiI2NTNjNzY2MDMiLCJ0ZWFtSWQiOiI3ZGYxZTU0NjdkIiwidXNlcklkIjoiNWUyNmM0YjAiLCJzZWNyZXRLZXkiOiI1YmIzZTdmMTQ5NGQ0OWFmODA5Yzg5YmYyZjhlYWJhZCIsImlhdCI6MTc4NzE3MjI4NywiZXhwIjoxODgxNzgwMjg3fQ.1ytRBgfmVbf6xZRVIIKvmM0wwoUKata3P9toyItHlF0',
    'api_url' => '',
    'api_key_header' => '',
    'cut_type' => 'complete',              // complete | normal | blur
    'scenes' =>
    array (
      // '923' => 'Studio hell',           // <-- SPYNE-SZENEN HIER
      // '924' => 'Studio dunkel',
    ),
    'guideline' => '',
    'resolution' => '',
    'retouching_accuracy' => '',
    'blur_license_plate' => false,
    'rembg_path' => '',
    'rembg_model' => 'u2net',
  ),
  'google' =>
  array (
    'client_id' => '',
    'client_secret' => '',
    'redirect_uri' => '',
  ),
  'instagram' =>
  array (
    'client_id' => '',
    'client_secret' => '',
    'redirect_uri' => '',
  ),
  'autoscout' =>
  array (
    'platform_username' => '',
    'platform_password' => '',
    'api_url' => '',
  ),

  // Stripe. Webhook-Adresse: https://rapid-car.com/api/payments/stripe-webhook.php
  // Ereignisse: checkout.session.completed UND checkout.session.async_payment_succeeded.
  // invoices erzeugt je Kauf eine Stripe-Rechnung; automatic_tax erst nach
  // Einrichtung von Stripe Tax im Dashboard auf true setzen.
  // methods leer = die Kasse zeigt alles, was im Stripe-Konto aktiv ist.
  'payment' =>
  array (
    'provider' => 'stripe',
    'api_key' => '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',
    'webhook_secret' => 'whsec_mPThlIwVqUSjFhJpkYoYM9uesWsTps5X',
    'invoices' => true,
    'automatic_tax' => false,
    'methods' => array (),
  ),
  'http' =>
  array (
    'ca_bundle' => '',
  ),
  'operator' =>
  array (
    'email' => 'masesitesinfo@gmail.com',
    'password_hash' => '$2y$10$VwC8Ea5LyCkVIf3Lf0Nyau9.N5YNOFVUDEU6fBjq9kpteRLevo.Da',
    'first_name' => 'Matteo',
    'last_name' => 'Betreiber',
    'tenant_name' => 'RapidCar',
    'credits' => 100,
  ),
);
